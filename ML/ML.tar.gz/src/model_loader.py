import joblib
from config import PIPELINE

MODEL_PIPELINE = joblib.load(PIPELINE)